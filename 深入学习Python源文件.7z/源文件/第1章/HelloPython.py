print 'Hello,Python!'
