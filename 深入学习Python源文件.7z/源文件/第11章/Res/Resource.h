//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Res.rc
//
#define IDD_DIALOG1                     7000
#define IDC_EDIT1                       7000
#define IDC_CHECK1                      7001
#define IDR_MENU1                       7001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        7002
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         7002
#define _APS_NEXT_SYMED_VALUE           7000
#endif
#endif
