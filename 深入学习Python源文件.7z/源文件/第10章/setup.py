#file: setup.py
import distutils
import py2exe
distutils.core.setup(windows=['MessageBox.py'])

