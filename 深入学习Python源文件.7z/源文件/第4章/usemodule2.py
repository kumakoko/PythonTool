# file: usemodule2.py
#
import mymodule2
mymodule2.show()
print 'my __name__ is', __name__

