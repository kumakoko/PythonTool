def show():
	print 'I am a moudle!'
name = 'mymodule.py'

