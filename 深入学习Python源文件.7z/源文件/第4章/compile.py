# file: compile.py
#
import   py_compile;     
py_compile.compile('usemodule.py'); 

