# file: mymodule2.py
#
def show():
	print 'I am a module!'
if __name__ == '__main__':
	show()
	print 'I am not a module!'
