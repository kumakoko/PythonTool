import myswig
myswig.show('Hi,SWIG','MYSWIG')
