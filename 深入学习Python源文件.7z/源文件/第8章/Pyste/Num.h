class Num
{
	int value;
	void set( int n )
	{
		value = n;
	}
	int get()
	{
		return value;
	}	
};
