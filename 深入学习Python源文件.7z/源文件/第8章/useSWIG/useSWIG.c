#include <stdio.h>
void showSWIG()
{
	printf("Hi,SWIG!\n");
}