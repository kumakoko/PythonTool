import useSWIG
useSWIG.showSWIG()
