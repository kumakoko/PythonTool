def sum(l):
	r = 0
	for i in l:
		r = r + i
	print 'Using Function sum'
	print 'The result is:',
	print r
def strsplit(s, c):
	r = s.split(c)
	return r
